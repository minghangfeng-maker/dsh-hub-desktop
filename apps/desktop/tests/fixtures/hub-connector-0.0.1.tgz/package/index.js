/**
 * Placeholder Hub connector.
 *
 * The Hub connector is delivered with the installer as a core plugin and is
 * replaced in place by later Hub releases, so this package proves the activation
 * path instead: it registers the `hubConnector` service and prints one line that
 * names the configuration layer that reached it together with the Host runtime
 * environment its agent shells inherit.
 *
 * The line goes to the Host's stdout rather than the Cordis logger: a desktop
 * Host installs no logger exporter, and this placeholder exists so an operator can
 * read the activation and environment facts from the application log.
 */

/** Package version reported by the placeholder service. */
export const version = '0.0.1'

/**
 * Redact credentials from a proxy URL before it reaches a log line.
 * @param value - Environment value to report.
 * @returns The value with any `user:password@` part removed.
 */
function redactCredentials(value) {
  return value.replace(/\/\/[^/@]*@/u, '//')
}

/**
 * Report the Host environment facts this connector's agent shells inherit.
 * Paths, a proxy origin, and an encoding switch carry no secrets; a proxy
 * credential never reaches the log.
 * @param env - The Host process environment.
 * @returns One `key=value` summary line.
 */
function describeHostEnvironment(env) {
  const path = env.PATH ?? env.Path ?? ''
  const python = path.split(';')[0] ?? ''
  const proxy = env.HTTPS_PROXY ?? env.https_proxy ?? ''
  return [
    `pwsh=${env.DSH_PWSH_PATH ?? 'unset'}`,
    `pythonPath=${python === '' ? 'unset' : python}`,
    `pythonUtf8=${env.PYTHONUTF8 ?? 'unset'}`,
    `httpsProxy=${proxy === '' ? 'unset' : redactCredentials(proxy)}`,
  ].join(' ')
}

/**
 * Register the placeholder service and report the effective configuration.
 * @param ctx - Host context this plugin mounts on.
 * @param config - Row configuration; `configSource` names the layer that supplied it.
 */
export function apply(ctx, config = {}) {
  const configSource = typeof config.configSource === 'string' ? config.configSource : 'default'
  const service = Object.freeze({
    version,
    configSource,
    describe: () => ({ name: '@dsh-hub/hub-connector', version, configSource }),
  })
  ctx.effect(() => ctx.provide('hubConnector', service), 'hub-connector: service')
  console.info(`hub-connector: active version=${version} configSource=${configSource} ${describeHostEnvironment(process.env)}`)
}

export const name = 'hub-connector'
export const inject = []
